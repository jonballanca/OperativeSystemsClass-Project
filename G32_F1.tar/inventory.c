#include "inventory.h"
#include "config.h"

void printa (int fd, char* sentence) {
    write (fd, sentence, strlen(sentence));
}

int readInventoryFile (Inventory* inventory ,char* file_name) {
    int fd = 0;             //Numero del file descriptor del fichero
    int read_bytes = 0;     //Numero de bytes leidos
    int result;             //Resultado

    Product product;        //Producto auxliar 

    inventory->product_count = 0;
    
    fd = open (file_name, O_RDONLY);

    if (fd < 0) {
        //Error reading file
        showText("Error reading inventory file\n");
        result = ERROR_INVENTORY_FILE;
    } else {
        //Reading file
        do {
            read_bytes = read (fd, &product, sizeof(Product));

            if (read_bytes > 0) {

                inventory->product_count ++;

                if (inventory->product_count == 1) {

                    inventory->products = (Product*) malloc (sizeof(Product)*inventory->product_count);

                } else {
                    inventory->products = (Product*) realloc (inventory->products, sizeof(Product)*inventory->product_count);
                }
                
                strcpy(inventory->products[inventory->product_count - 1].name, product.name);
                inventory->products[inventory->product_count - 1].amount = product.amount;
                inventory->products[inventory->product_count - 1].weight = product.weight;

            }

        } while (read_bytes > 0);
        result = NO_ERROR;
        close(fd);
    }


    return result;
}

void updateStock (Inventory* inventory, Product product, int option) {
    int i = 0;              // Contador
    int found = 0;          //Flag que indica si se ha encontrado o no un producto

    //Bucle para encontar el producto para poder añadirlo o restarlo
    for (i = 0; i < inventory->product_count && !found; i++) {
        if (strcmp (inventory->products[i].name, product.name) == 0) {
            found = 1;

            if (option == ADD) {
                inventory->products[i].amount += product.amount;

            } else {
                if (option == REMOVE) {
                    inventory->products[i].amount -= product.amount;

                    if (inventory->products[i].amount < 0) {
                        inventory->products[i].amount = 0;
                    }
                }
            }
        }
    }
    
}

void tradeFile (Inventory inventory, char* file_name) {
    int fd = 0;         //Numero del file descriptor del fichero
    int i = 0;          //Contador
    int buffer_size;    //Tamaño del buffer

    char* buffer;       //Variable auxiliar para printar por pantalla

    fd = open(file_name ,O_WRONLY|O_CREAT|O_TRUNC,  S_IRUSR | S_IWUSR | S_IRGRP | S_IROTH);

    if (fd < 0) {
        showText ("Error opening send file\n");
    } else {
        printa (fd, "--- Trade File ---\n");
        printa (fd, "Item\t\t\t| Value (Gold)\n");
        printa (fd, "----------------------------------------\n");    

        //Crea un fichero con la información del inventario puesta
        for (i = 0; i < inventory.product_count; i++) {
            buffer_size = asprintf(&buffer, "%s", inventory.products[i].name);
            write (fd, buffer, buffer_size);
            free (buffer);

            if (strlen(inventory.products[i].name) < 8) {
                write(fd, "\t\t\t", strlen("\t\t\t"));
            } else if ((strlen(inventory.products[i].name) >= 8) && (strlen(inventory.products[i].name) < 16)) {
                write(fd, "\t\t", strlen("\t\t"));
            } else if ((strlen(inventory.products[i].name) >= 16) && (strlen(inventory.products[i].name) < 24)) {
                write(fd, "\t", strlen("\t"));
            }

            buffer_size = asprintf(&buffer, "| %d\t\n", inventory.products[i].amount);
            write (fd, buffer, buffer_size);
            free (buffer);
        }
        
        printa (fd, "----------------------------------------\n");
        
        buffer_size = asprintf (&buffer, "Total Entries: %d\n\n", inventory.product_count);
        write (fd, buffer, buffer_size);
        free (buffer);

        
    }

}

void listProduct(Inventory inventory) {
    int i = 0, j = 0;           //Contadores
    int buffer_size;            //Tamaño del buffer 

    char* buffer;               //Variable auxiliar para printar

    showText ("--- Trade Ledger ---\n");
    showText ("Item\t\t\t| Value (Gold)\t| Weight (Stone)\n");
    showText ("--------------------------------------------------------\n");    

    //Muestra los productos
    for (i = 0; i < inventory.product_count; i++) {
        buffer_size = asprintf(&buffer, "%s", inventory.products[i].name);
        write (1, buffer, buffer_size);
        free (buffer);

        if (strlen(inventory.products[i].name) < 8) {
            showText("\t\t\t");
        } else if ((strlen(inventory.products[i].name) >= 8) && (strlen(inventory.products[i].name) < 16)) {
            showText("\t\t");
        } else if ((strlen(inventory.products[i].name) >= 16) && (strlen(inventory.products[i].name) < 24)) {
            showText("\t");
        }

        buffer_size = asprintf(&buffer, "| %d\t\t| %.1f\n", inventory.products[i].amount, inventory.products[i].weight);
        write (1, buffer, buffer_size);
        free (buffer);
    }
    
    showText ("--------------------------------------------------------\n");
    
    buffer_size = asprintf (&buffer, "Total Entries: %d\n\n", inventory.product_count);
    write (1, buffer, buffer_size);
    free (buffer);

}