/***********************************************
*
* @Proposit: Controlar la logica del maester, que consiste en recibir y hacer la logica para cada uno de los comandos
* @Autor/s: Jon Ballanca y Alejandro Cortes
* @Data creacio: 20 / 10 / 2025
* @Data ultima modificacio: 26 / 10 / 2025
*
************************************************/

#define _GNU_SOURCE
#include <stdio.h> // snprintf, asprintf, etc
#include <stdlib.h> // Per atoi
#include <string.h> // Per strlen
#include <unistd.h> // Per read i write
#include <sys/stat.h> // Per constants de modes (permisos del archiu) com S_IRUSR
#include <fcntl.h> // Per open i constants del tipo de open com O_RDONLY
#include <time.h> //Per poder agafar la informacio del temps actual
#include <signal.h> //Signals
#include <pthread.h> // Threads

#include "config.h"
#include "commands.h"
#include "inventory.h"



/***********************************************
*
* @Finalitat: Mostrar un mensaje de error para cuando hay un error de string vacio
* @Parametres: ---
* @Retorn:  ---
*
************************************************/
void emptyStringError () {
    int printing;       // Variable de tipo entero que guarda el número de bytes para escribir por la termina 
    char* buffer;       // Buffer que guarda un string temporalmente para poder convertirlo a mayúsculas

    printing = asprintf(&buffer, RED BOLD "You enterd an empty string as a command. Please try again.%s\n", RESET);
    write(1, buffer, printing);
    free(buffer);
}

/***********************************************
*
* @Finalitat: Harcodear información para las pruebas de la fase 1. No se utiliza esta función al final.
* @Parametres: ---
* @Retorn: Inventario con la información hardcodeada para las pruebas de la fase1
*
************************************************/
Inventory requestAvailableProducts () {
    Inventory inventory;            // Inventario que se hardcodea para la Fase 1, la que es el trade
                                    // No se utiliza esta función al final.

    /* Hardcode de dos productos para la Fase 1 */

    inventory.product_count = 2;

    inventory.products = (Product*)malloc(sizeof(Product) * inventory.product_count);

    strcpy(inventory.products[0].name, "Myrish Lace");
    strcpy(inventory.products[1].name, "Sweetwine");

    inventory.products[0].amount = 150;
    inventory.products[1].amount = 80;

    inventory.products[0].weight = 4.2;
    inventory.products[1].weight = 9.5;

    return inventory;
}

/***********************************************
*
* @Finalitat: Crea una copia con del inventario que con el que se quiere tradear con el amount en 0
* @Parametres: in: avail_inventory = inventario con el que se desea trader
* @Retorn: La copia del inventario con el que se desea tradear con el amount en 0
*
************************************************/
Inventory createTradeInventory (Inventory avail_inventory) {
    Inventory trade;    // Inventario que se crea y representa el trade del start trade
    int i = 0;          // Contador

    trade.products = (Product*)malloc(sizeof(Product) * avail_inventory.product_count);

    for (i = 0; i < avail_inventory.product_count; i++) {
        strcpy(trade.products[i].name, avail_inventory.products[i].name);
        trade.products[i].amount = 0;
        trade.products[i].weight = avail_inventory.products[i].weight;
    }

    return trade;
}

/***********************************************
*
* @Finalitat: Añade la información de los productos en el invetario trade, y los resta en el avail.
* @Parametres:  in/out: avail_inventory = inventario con el que se desea tradear
                in/out: trade = inventario que indica que se desea tradear
                in: arguments = nombre del producto que se desea tradear y la cantidad
* @Retorn: ---
*
************************************************/
void addToTrade (Inventory* avail_inventory, Inventory* trade, char** arguments) {
    int i = 0;              // Contador
    char * aux_name;        // Buffer que guarda un string temporalmente para poder convertirlo a mayúsculas

    for (i = 0; i < (*avail_inventory).product_count; i++) {
        aux_name = (char*)malloc(sizeof(char) * (strlen((*avail_inventory).products[i].name) + 1));
        strcpy(aux_name, (*avail_inventory).products[i].name);
        convertToCapitalLetters(aux_name);

        if (!strcmp(arguments[FIRST_ARGUMENT], aux_name)) {
            (*trade).products[i].amount += atoi(arguments[SECOND_ARGUMENT]);
            (*avail_inventory).products[i].amount -= atoi(arguments[SECOND_ARGUMENT]);
        }

        free(aux_name);
    }
}

/***********************************************
*
* @Finalitat: Resta la información de los productos en el invetario trade, y los añade en el avail.
* @Parametres:  in/out: avail_inventory = inventario con el que se desea tradear
                in/out: trade = inventario que indica que se desea tradear
                in: arguments = nombre del producto que se desea tradear y la cantidad
* @Retorn: ---
*
************************************************/
void removeFromTrade (Inventory* avail_inventory, Inventory* trade, char** arguments) {
    int i = 0;              // Contador
    char * aux_name;        // Buffer que guarda un string temporalmente para poder convertirlo a mayúsculas

    for (i = 0; i < (*avail_inventory).product_count; i++) {
        aux_name = (char*)malloc(sizeof(char) * (strlen((*avail_inventory).products[i].name) + 1));
        strcpy(aux_name, (*avail_inventory).products[i].name);
        convertToCapitalLetters(aux_name);
        
        if (!strcmp(arguments[FIRST_ARGUMENT], aux_name)) {
            (*trade).products[i].amount -= atoi(arguments[SECOND_ARGUMENT]);
            (*avail_inventory).products[i].amount += atoi(arguments[SECOND_ARGUMENT]);
        }

        free(aux_name);
    }
}

/***********************************************
*
* @Finalitat: Muestra el mensaje de que se ha enviado un trade
* @Parametres:  in: trade = productos y cantidad que se desean tradear
                in: realm = nombre del reino con el que se desea tradear
* @Retorn: ---
*
************************************************/
void sendTrade (Inventory trade, char* realm) {
    /* Hardcode de Send Trade para la Fase 1 */
    
    int printing;           // Entero que guarda el número de los bytes para escribir
    char* buffer;           // Buffer que guarda lo que se quiere escribir por la terminal

    printing = asprintf(&buffer, "Trade list sent to %s.\n", realm);
    write(1, buffer, printing);
    free(buffer);
}


/***********************************************
*
* @Finalitat: Liberar la información de los productos auxiliars
* @Parametres:  in/out: inventory = información que se desea liberar
                in/out: trade = información que se desea liberar
* @Retorn: ---
*
************************************************/
void freeProducts(Inventory *inventory, Inventory *trade) {
    /*if (inventory != NULL) {
        free(inventory->products);
        inventory->products = NULL; 
        inventory->product_count = 0;
    }*/

    if (trade != NULL) {
        free(trade->products);
        trade->products = NULL;
        trade->product_count = 0;
    }
}

/***********************************************
*
* @Finalitat: Mostrar los productos que estan disponibles para tradear
* @Parametres:  in: inventory = productos que estan disponibles para tradear
* @Retorn:  ---
*
************************************************/
void showAvailableProducts (Inventory inventory) {
    int i = 0;              // Contador
    int printing = 0;      // Entero que guarda el número de los bytes para escribir   
    char* buffer;           // Buffer que guarda lo que se quiere escribir por la terminal

    showText("Available products: ");

    for (i = 0; i < inventory.product_count; i++) {
        printing = asprintf(&buffer, "%s", inventory.products[i].name);
        write(1, buffer, printing);
        free(buffer);

        if (i == (inventory.product_count - 1)) {
            showText(".\n");
        } else {
            showText(", ");
        }
    }
}

/***********************************************
*
* @Finalitat: Ensenyar un mensaje para aqullos commandos no implementados que esten escritos correctamente
* @Parametres:  ---
* @Retorn:  ----
*
************************************************/
void notImplementedYet(){
    showText("Command OK\n");
}

/***********************************************
*
* @Finalitat: Listar todos los reinos que conoce este maester
* @Parametres:  in: maester = contiene toda la informacion del maester, entre otros los nombres de los reinos conocidos 
* @Retorn:  ---
*
************************************************/
void listRealms(MaesterInfo maester) {
    int i = 0;              // Contador
    int num_bytes = 0;      // Entero que guarda el número de los bytes para escribir   
    char* buffer;           // Buffer que guarda lo que se quiere escribir por la terminal

    for (i = 0; i < maester.num_routes; i++) {
        num_bytes = asprintf(&buffer, "- %s\n", maester.routes[i].realm_name);
        write(1, buffer, num_bytes);
        free(buffer);
    }
}

/***********************************************
*
* @Finalitat: Hacer un pledge (No implementado)
* @Parametres:  ---
* @Retorn:  ---
*
************************************************/
void pledge(){
    notImplementedYet();
}

/***********************************************
*
* @Finalitat: Responder a un pledge (No implementado)
* @Parametres: ---
* @Retorn:  ---
*
************************************************/
void pledgeRespond(){
    notImplementedYet();
}

/***********************************************
*
* @Finalitat: Listar los productos de un reino que no sea el propio (No implementado)
* @Parametres:  ---
* @Retorn:  ---
*
************************************************/
void listProductsMaester(){
    notImplementedYet();
}

/***********************************************
*
* @Finalitat: Listar los productos del propio reino
* @Parametres:  in: inventory = inventorio que se desea listar
* @Retorn: ---
*
************************************************/
void listProductsNoArgs(Inventory inventory){
    listProduct(inventory);
}

/***********************************************
*
* @Finalitat: Hacer toda la lógica del submenu startTrade, que consiste en ir recibiendo subcomandos e ir 
                añadiendo o removiendo productos o enviar o cancelar la operación de comercio 
* @Parametres:  in: realm = nombre del reino con el que se desea intercambiar
                in: maester = información del reino
                in: avail_inventory = productos con los que se puede comerciar
* @Retorn:  ----
*
************************************************/
void startTrade (char *realm, MaesterInfo maester, Inventory avail_inventory) {
    char *buffer;                       // El buffer que se utiliza para guardar lo que se escribe por pantalla
    char *string_read;                  // El string que guarda lo que se lee desde la terminal
    char **command_separated = NULL;    // Array de strings que guarda cada palabra del comando inicial por separado
    char *command;                      // String que guarda el comando
    char **command_args = NULL;         // Array de strings que guarda cada argumento de "trade" por separado
    int printing = 0;                   // Variable que guarda los bytes para escribir por la terminal
    int word_count = 0;                 // Guarda el número de palabras que se han escrito como comando de "trade"
    int exit_flag = 0;                  // Flag que guarda si se tiene que salir de estar esperando a los comandos de "trade"
    int argument_count = 0;             // Guarda el número de argumentos que contiene el comando de "trade"
    int command_index;                  // El entero que guarda el index que representa el comando de "trade"
    Inventory trade;                    // El inventario auxiliar para hacer el trade

    printing = asprintf(&buffer, "Entering trade mode with %s.\n", realm);
    write(1, buffer, printing);
    free(buffer);

    // avail_inventory = requestAvailableProducts();
    showAvailableProducts(avail_inventory);

    trade = createTradeInventory(avail_inventory);

    //Bucle para leer los comandos y hacer la lógica de ellos
    do {
        word_count = 0;

        //Leer y comprobar que no hay errores
        showText("(trade)> ");
        string_read = readUntil(0, '\n');
        command_separated = NULL;
        if (string_read != NULL) {
            word_count = separateCommand(&command_separated, string_read);
            if (command_separated != NULL) {
                argument_count = separateTradeArgs(&command, &command_args, command_separated, word_count);
                command_index = getTradeIndex(command, command_args, avail_inventory, trade, argument_count, maester);
            } else {
                emptyStringError();
            }
        } else {
            emptyStringError();
        }

        //Hacer la lógica de cada comando
        switch (command_index) {
            case INVALID_COMMAND:
                // Hacer nada; No hacer ningun commando. Los errores ya se han controlado
                break;
            case ADD:
                addToTrade(&avail_inventory, &trade, command_args);
                break;
            case REMOVE:
                removeFromTrade(&avail_inventory, &trade, command_args);
                break;
            case SEND:
                sendTrade(trade, realm);
                
                buffer = malloc(sizeof(char) * (strlen(realm) + strlen(".txt")));
                buffer = strcat(realm, ".txt");

                tradeFile(trade, buffer);
                //free(buffer);
                freeProducts(&avail_inventory, &trade);
                exit_flag = 1;
                break;
            case CANCEL:
                // Hay que recuperar
                freeProducts(&avail_inventory, &trade);
                exit_flag = 1;
                break;
            default:
                break;
        }

        //Liberar memoria de las variables auxiliares
        if (string_read != NULL) {
            free(string_read);
            if (command_separated != NULL) {
                free(command);
                if (argument_count != 0) {
                    for (int i = 0; i < argument_count; i++) {
                        free(command_args[i]);
                    }
                    free(command_args);
                    argument_count = 0;
                }
                for (int i = 0; i < word_count; i++) {
                    free(command_separated[i]);
                }
                free(command_separated);
            }
        }

    } while (!exit_flag);
}

/***********************************************
*
* @Finalitat: Mirar el estado de los pledge (No implementado)
* @Parametres: ---
* @Retorn:  ---
*
************************************************/
void pledgeStatus(){
    notImplementedYet();
}

/***********************************************
*
* @Finalitat: Mirar el  estado de los envoy (No implementado)
* @Parametres: ---
* @Retorn: ---
*
************************************************/
void envoyStatus(){
    notImplementedYet();
}

/***********************************************
*
* @Finalitat: Liberar la memoria de la información utilizada por el maesster
* @Parametres:  in/out: maester = información que se desea liberar sobre el maester
                in/out: maester = información que se desea liberar sobre los productos
* @Retorn:  ---
*
************************************************/
void exitMaester(MaesterInfo* maester, Inventory* inventory){
    int i = 0;      // Contador

    // Libera información del inventario
    if (inventory != NULL) {
        free(inventory->products);
        inventory->products = NULL; 
        inventory->product_count = 0;
    }

    // Libera información del maester
    if(maester != NULL){
        if (maester->routes != NULL) {
            for (i = 0; i < maester->num_routes; i++) {
                free(maester->routes[i].realm_name);
            }
        }
        free(maester->routes);
        maester->routes = NULL;
        free(maester->realm_name);
        maester->realm_name = NULL;
        free(maester->path);
        maester->path = NULL;

        maester->num_routes = 0;
    }
}


// Procedimiento principal.
int main (int argc, char **argv) {
    Inventory inventory;                // El inventario del maester
    MaesterInfo maester;                // La estrcutura de información que representa el maester

    char *string_read;                  // El string que guarda lo que se lee desde la terminal
    char *buffer;                       // El buffer que se utiliza para guardar lo que se escribe por pantalla
    char *command;                      // String que guarda el comando
    char **command_separated = NULL;    // Array de strings que guarda cada palabra del comando inicial por separado
    char **command_args = NULL;         // Array de strings que guarda cada argumento por separado

    int error_config_file = 0;          // Flag que guarda si hay un error en el fichero de configuración
    int error_inventory_file = 0;       // Flag que guarda si hay un error en el fichero del inventario
    int file_errors = 0;                // Flag que guarda si hay un error en cualquier o los dos ficheros
    int printing = 0;                   // Variable que guarda los bytes para escribir por la terminal
    int exit_flag = 0;                  // Flag que guarda si se tiene que salir de estar esperando a los comandos
    int word_count = 0;                 // Guarda el número de palabras que se han escrito como comando
    int argument_count = 0;             // Guarda el número de argumentos que contiene el comando
    int command_index = 0;              // Guarda el comando como el index que representa baseado en el commands.h
    
    // Si se han entrado menos que 3 argumentos
    if (argc < 3) {
        showText("\nToo few arguments to initialize the maester.\n");
    } else {

        // Si se han entrado mas que 3 aegumentos
        if (argc > 3) {
            showText("\nToo many arguments to initialize the maester.\n");
        } else {
            error_config_file = readConfigFile(&maester, argv[1]);
            error_inventory_file = readInventoryFile(&inventory, "stormlands_stock.db");

            file_errors = checkFileErrors(error_config_file, error_inventory_file);

            // Si no hay ningún error en ningún fichero
            if (!file_errors) {
                printing = asprintf(&buffer, "%s initialized. The board is set.\n", maester.realm_name);
                write(1, buffer, printing);
                free(buffer);
                
                exit_flag = 0;

                // Recorre el bucle de comandos mientras que el usuario no escribe "EXIT"
                do {
                    word_count = 0;

                    showText(BOLD "$ ");

                    // Lee el del usuario desde la terminal
                    string_read = readUntil(0, '\n');
                    printing = asprintf(&buffer, "%s", RESET);
                    write(1, buffer, printing);
                    free(buffer);

                    // Se reinicia el array
                    command_separated = NULL;

                    // Si se ha leido algo
                    if (string_read != NULL) {

                        // Si lo que ha leido no ha sido todo espacios
                        word_count = separateCommand(&command_separated, string_read);
                        if (command_separated != NULL) {
                            
                            // Se separa el string leido en comando y argumentos
                            argument_count = separateArguments(&command, &command_args, command_separated, word_count);

                            // Se guarda el index del comando
                            command_index = getCommandIndex(command, command_args, argument_count, maester);
                        } else {
                            emptyStringError();
                        }
                    } else {
                        emptyStringError();
                    }
                   
                    // A partir de aqui, solo trabajamos con command y command_args
                    // Se separa cada caso de cada comando en el switch
                    switch (command_index) {
                        case INVALID_COMMAND:
                            // Hacer nada; No hacer ningun commando. Los errores ya se han controlado
                            break;
                        case LIST_REALMS:
                            listRealms(maester);
                            break;
                        case PLEDGE:
                            pledge();
                            break;
                        case PLEDGE_RESPOND:
                            pledgeRespond();
                            break;
                        case LIST_PRODUCTS:
                            listProductsMaester();
                            break;
                        case LIST_PRODUCTS_NO_ARGS:
                            listProductsNoArgs(inventory);
                            break;
                        case START_TRADE:
                            startTrade(command_args[FIRST_ARGUMENT], maester, inventory);
                            break;
                        case PLEDGE_STATUS:
                            pledgeStatus();
                            break;
                        case ENVOY_STATUS:
                            envoyStatus();
                            break;
                        case EXIT:
                            exitMaester(&maester, &inventory);
                            exit_flag = 1;

                            break;
                        default:
                            break;
                    }

                    // Liberar memoria de las variables que reservan su memoria
                    if (string_read != NULL) {
                        free(string_read);
                        if (command_separated != NULL) {
                            free(command);
                            for (int i = 0; i < argument_count; i++) {
                                free(command_args[i]);
                            }
                            if (command_args != NULL) {
                                free(command_args);
                                for (int i = 0; i < word_count; i++) {
                                    free(command_separated[i]);
                                }
                                free(command_separated);
                            }
                        }
                    }
                    
                } while(!exit_flag); //Tiene que hacerlo hasta que sea exit
            }
        }
    }


    return 0;
}
